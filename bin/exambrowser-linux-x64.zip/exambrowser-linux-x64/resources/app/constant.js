module.exports = {
  mainwindow: {
    width: {
      linux: 500,
      win32: 500,
      darwin: 500
    },
    height: {
      linux: 275,
      win32: 275,
      darwin: 300
    }
  },
  aboutwindow: {
    width: {
      linux: 500,
      win32: 500,
      darwin: 500
    },
    height: {
      linux: 250,
      win32: 250,
      darwin: 250
    }
  },
  passwordwindow: {
    width: {
      linux: 300,
      win32: 300,
      darwin: 300
    },
    height: {
      linux: 150,
      win32: 150,
      darwin: 175
    }
  },
  settingswindow: {
    width: {
      linux: 500,
      win32: 500,
      darwin: 500
    },
    height: {
      linux: 250,
      win32: 250,
      darwin: 275
    }
  },
  settingsadminwindow: {
    width: {
      linux: 500,
      win32: 500,
      darwin: 500
    },
    height: {
      linux: 325,
      win32: 325,
      darwin: 325
    }
  }
}
